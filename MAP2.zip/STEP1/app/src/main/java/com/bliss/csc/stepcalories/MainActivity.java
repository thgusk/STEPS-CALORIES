package com.bliss.csc.stepcalories;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.pedro.library.AutoPermissions;
import com.pedro.library.AutoPermissionsListener;

public class MainActivity extends AppCompatActivity implements SensorEventListener, AutoPermissionsListener {

    private SensorManager sensorManager;
    private Sensor StepCountSensor;
    private Sensor PressureSensor;


    TextView tvStepCount, tvCal;

    float height, p_height, ver;
    double prevLocation_x, prevLocation_y;
    float[] mov;
    public static float stepCount;
    float mov_dis, gradient, g_rate, calorie = 0;

    Button btnActivity, btnMap, btnLogin;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        tvStepCount = (TextView)findViewById(R.id.tvStepCount);
        tvCal = (TextView)findViewById(R.id.tvCal);
        btnActivity = (Button)findViewById(R.id.btnActivity);
        btnMap = (Button)findViewById(R.id.btnMap);
        btnLogin = (Button)findViewById(R.id.btnLogin);

        btnActivity.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent Activity = new Intent(getApplicationContext(),Activation.class);
                startActivity(Activity);
            }
        });

        btnMap.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent Map = new Intent(getApplicationContext(),Map.class);
                startActivity(Map);
            }
        });

        btnLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent Login = new Intent(getApplicationContext(),Login.class);
                startActivity(Login);
            }
        });

        sensorManager = (SensorManager) getSystemService(Context.SENSOR_SERVICE);
        StepCountSensor = sensorManager.getDefaultSensor(Sensor.TYPE_STEP_COUNTER);
        PressureSensor = sensorManager.getDefaultSensor(Sensor.TYPE_PRESSURE);

        if (StepCountSensor == null) {
            Toast.makeText(this, "No step detect sensor", Toast.LENGTH_SHORT).show();
        }
        if (PressureSensor == null) {
            Toast.makeText(this, "No pressure sensor", Toast.LENGTH_SHORT).show();
        }
    }

    /////////센서메소드/////////
    @Override
    public void onSensorChanged(SensorEvent sensorEvent) {
        if (sensorEvent.sensor.getType() == Sensor.TYPE_PRESSURE) {     //기압->고도
            float presure = sensorEvent.values[0];
            height = SensorManager.getAltitude(SensorManager.PRESSURE_STANDARD_ATMOSPHERE, presure);
            height = (float) (Math.round(height * 100) / 100.0);
            ver = height - p_height;
            p_height = height;
        }
        if (sensorEvent.sensor.getType() == Sensor.TYPE_STEP_COUNTER) {     //걸음수
            stepCount = sensorEvent.values[0];
            tvStepCount.setText(stepCount+" 걸음");

            startLocationService();

            calorie += 1.44+1.94*Math.pow(ver,0.43)+0.24*Math.pow(ver,4)+0.34*ver*g_rate*(1-Math.pow(1.05,(1-Math.pow(1.11,(g_rate+32)))));     //칼로리계산
            // EE=1.44+1.94*S^0.43+0.24*S^4+0.34*S*G*[1-1.05^<1-1.11^(G+32)>]   S=ver, G=g_rate
            if(calorie < 1000){
                tvCal.setText(calorie +" cal");
            }else{
                double d_calorie = (double) calorie;
                float kCalorie = (float) (Math.round(d_calorie / 1000*0.01) * 0.01);
                tvCal.setText(kCalorie +" kcal");
            }
        }

    }

    @Override
    public void onAccuracyChanged(Sensor sensor, int i) {

    }

    @Override
    protected void onResume() {
        // Register a listener for the sensor.
        super.onResume();
        sensorManager.registerListener(this, PressureSensor, SensorManager.SENSOR_DELAY_NORMAL);
        sensorManager.registerListener(this, StepCountSensor, SensorManager.SENSOR_DELAY_NORMAL);
    }

    @Override
    protected void onPause() {
        // Be sure to unregister the sensor when the activity pauses.
        super.onPause();
        sensorManager.unregisterListener(this);
    }

    /////////위치메소드/////////
    //위치 관리자 객체 참조
    public void startLocationService() {
        LocationManager manager = (LocationManager) getSystemService(Context.LOCATION_SERVICE);
        try {
            Location location = manager.getLastKnownLocation(LocationManager.GPS_PROVIDER);
            if (location != null){
                double latitude = location.getLatitude();
                double longitude = location.getLongitude();
                location.distanceBetween(prevLocation_y,prevLocation_x,latitude,longitude,mov);
                mov_dis += mov[0];
                prevLocation_y = latitude;
                prevLocation_x = longitude;
                double root = Math.sqrt(Math.pow(mov[0],2) + Math.pow(ver,2));
                gradient = (float) Math.acos(mov[0]/root);   //위치 값과 고도 변화값으로 경사 각도계산
                g_rate = gradient *20/9;    //경사도

            }

            //리스터 객체 생성해 위치 관리자에게 위치정보 업데이트 요청
            GPSListener gpsListener = new GPSListener();
            long minTime = 10000;
            float minDistance = 0;

            manager.requestLocationUpdates(LocationManager.GPS_PROVIDER,minTime,minDistance,gpsListener);
            Toast.makeText(getApplicationContext(),"내 위치확인 요청함",Toast.LENGTH_SHORT).show();

        }catch (SecurityException e){
            e.printStackTrace();
        }
    }


    @Override
    public void onDenied(int requestCode, String[] permissions) {
        Toast.makeText(this,"Permissions denied : "+permissions.length, Toast.LENGTH_SHORT).show();
    }

    @Override
    public void onGranted(int requestCode, String[] permissions) {
        Toast.makeText(this,"Permissions granted : "+permissions.length, Toast.LENGTH_SHORT).show();
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        AutoPermissions.Companion.parsePermissions(this,requestCode,permissions, this);
    }

    //위치 리스너
    class GPSListener implements LocationListener {
        public void onLocationChanged(Location location){
            Double latitude = location.getLatitude();
            Double longitude = location.getLongitude();
        }

        public void onProviderDisabled(String provider){}

        public void onProviderEnabled(String provider){}

        public void onStatusChanged(String provider, int status, Bundle extras){}
    }


}