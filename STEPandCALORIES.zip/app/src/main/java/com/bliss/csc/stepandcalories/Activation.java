package com.bliss.csc.stepandcalories;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;

public class Activation extends AppCompatActivity {
    //private Context mContext;

    Button btnMain, btnMap;
    TextView tvAvgStepCount,tvRecentStepCount,tvAvgTime,tvRecentTime;
    int stepCount1,stepCount2,stepCount3,stepCount4,stepCount5;
    int time1,time2,time3,time4,time5;
    String avgStepCount,recentStepCount,avgTime;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activation);
        //mContext = this;

        //액션바(툴바) 숨김
        ActionBar actionBar = getSupportActionBar();
        actionBar.hide();

        Intent intent = getIntent();
        stepCount1 = (int) intent.getFloatExtra("Count1",0);
        stepCount2 = (int) intent.getFloatExtra("Count2",0);
        stepCount3 = (int) intent.getFloatExtra("Count3",0);
        stepCount4 = (int) intent.getFloatExtra("Count4",0);
        stepCount5 = (int) intent.getFloatExtra("Count5",0);
        time1 = intent.getIntExtra("time1",0);
        time2 = intent.getIntExtra("time2",0);
        time3 = intent.getIntExtra("time3",0);
        time4 = intent.getIntExtra("time4",0);
        time5 = intent.getIntExtra("time5",0);


        tvAvgStepCount = (TextView)findViewById(R.id.avgStepCount);
        tvRecentStepCount = (TextView)findViewById(R.id.recentStepCount);
        tvAvgTime = (TextView)findViewById(R.id.avgTime);
        tvRecentTime = (TextView)findViewById(R.id.recentTime);
        btnMain = (Button)findViewById(R.id.btnMain);
        btnMap = (Button)findViewById(R.id.btnMap);

        float sum = stepCount1+stepCount2+stepCount3+stepCount4+stepCount5;
        avgStepCount = Float.toString(sum/5);
        tvAvgStepCount.setText("평균 걸음수  : "+avgStepCount+" 보");

        recentStepCount = Integer.toString(stepCount1);
        tvRecentStepCount.setText("최근 걸음수 : "+recentStepCount+" 보");

        int time_sum = time1 + time2 + time3 + time4 + time5;
        int int_avgTime = time_sum/5;
        if(int_avgTime/900 <60){
            avgTime = Integer.toString(int_avgTime/900);
            tvAvgTime.setText("평균 운동시간 : "+avgTime+" 초");
        }else{
            int min = int_avgTime/900/60;
            int sec = (int_avgTime/900)%60;
            tvAvgTime.setText("평균 온동시간 : "+min+"분 "+sec+"초");
        }


        if(time1/900 <60){
            avgTime = Integer.toString(time1/900);
            tvRecentTime.setText("최근 운동시간 : "+avgTime+" 초");
        }else{
            int min = time1/900/60;
            int sec = (time1/900)%60;
            tvRecentTime.setText("최근 온동시간 : "+min+"분 "+sec+"초");
        }

        btnMain.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });

        btnMap.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent Map = new Intent(getApplicationContext(),Map.class);
                startActivity(Map);
            }
        });


    }
}
