package com.bliss.csc.stepandcalories;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;

import static com.bliss.csc.stepandcalories.R.layout.map;

public class Map extends AppCompatActivity {

    Button btnMain,btnActivation;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(map);

        //액션바(툴바) 숨김
        ActionBar actionBar = getSupportActionBar();
        actionBar.hide();

        btnMain = (Button)findViewById(R.id.btnMain);
        btnActivation = (Button)findViewById(R.id.btnActivity);

        btnMain.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });

        btnActivation.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(),Activation.class);
                startActivity(intent);
            }
        });


    }
}
