package com.bliss.csc.stepandcalories;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;

import org.eazegraph.lib.charts.BarChart;
import org.eazegraph.lib.models.BarModel;

import java.util.ArrayList;

public class Activation extends AppCompatActivity {
    //private Context mContext;

    Button btnMain, btnMap;
    TextView tvAvgStepCount,tvRecentStepCount,tvAvgTime,tvRecentTime,tvAvgCalorie,tvRecentCalorie;
    int stepCount1,stepCount2,stepCount3,stepCount4,stepCount5;
    int time1,time2,time3,time4,time5;
    float calorie1,calorie2,calorie3,calorie4,calorie5;
    String avgStepCount,recentStepCount,avgTime,avgCalorie,recentCalorie;
    BarChart stepChart, calorieChart;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activation);
        //mContext = this;

        //액션바(툴바) 숨김
        ActionBar actionBar = getSupportActionBar();
        actionBar.hide();

        Intent intent = getIntent();
        stepCount1 = (int) intent.getFloatExtra("Count1",0);
        stepCount2 = (int) intent.getFloatExtra("Count2",0);
        stepCount3 = (int) intent.getFloatExtra("Count3",0);
        stepCount4 = (int) intent.getFloatExtra("Count4",0);
        stepCount5 = (int) intent.getFloatExtra("Count5",0);
        calorie1 = intent.getFloatExtra("calorie1",0);
        calorie2 = intent.getFloatExtra("calorie2",0);
        calorie3 = intent.getFloatExtra("calorie3",0);
        calorie4 = intent.getFloatExtra("calorie4",0);
        calorie5 = intent.getFloatExtra("calorie5",0);
        time1 = intent.getIntExtra("time1",0);
        time2 = intent.getIntExtra("time2",0);
        time3 = intent.getIntExtra("time3",0);
        time4 = intent.getIntExtra("time4",0);
        time5 = intent.getIntExtra("time5",0);


        tvAvgStepCount = (TextView)findViewById(R.id.avgStepCount);
        tvRecentStepCount = (TextView)findViewById(R.id.recentStepCount);
        tvAvgTime = (TextView)findViewById(R.id.avgTime);
        tvRecentTime = (TextView)findViewById(R.id.recentTime);
        tvAvgCalorie = (TextView)findViewById(R.id.avgCalorie);
        tvRecentCalorie = (TextView)findViewById(R.id.recentCalorie);
        btnMain = (Button)findViewById(R.id.btnMain);
        btnMap = (Button)findViewById(R.id.btnMap);
        stepChart = (BarChart)findViewById(R.id.barchart);
        calorieChart = (BarChart)findViewById(R.id.barchart1);


        float sum = stepCount1+stepCount2+stepCount3+stepCount4+stepCount5;
        avgStepCount = Float.toString(sum/5);
        tvAvgStepCount.setText("평균 걸음수  : "+avgStepCount+" 보");

        recentStepCount = Integer.toString(stepCount1);
        tvRecentStepCount.setText("최근 걸음수 : "+recentStepCount+" 보");

        int time_sum = time1 + time2 + time3 + time4 + time5;
        int int_avgTime = time_sum/5;
        if(int_avgTime/900 <60){
            avgTime = Integer.toString(int_avgTime/900);
            tvAvgTime.setText("평균 운동시간 : "+avgTime+" 초");
        }else{
            int min = int_avgTime/900/60;
            int sec = (int_avgTime/900)%60;
            tvAvgTime.setText("평균 온동시간 : "+min+"분 "+sec+"초");
        }

        if(time1/900 <60){
            String recentTime = Integer.toString(time1/900);
            tvRecentTime.setText("최근 운동시간 : "+recentTime+" 초");
        }else{
            int min = time1/900/60;
            int sec = (time1/900)%60;
            tvRecentTime.setText("평균 온동시간 : "+min+"분 "+sec+"초");
        }

        float calorie_sum = calorie1 + calorie2 + calorie3 + calorie4 + calorie5;
        float avg_Calorie = (float) (Math.round(calorie_sum/5/0.001)*0.001);
        avgCalorie = Float.toString(avg_Calorie);
        tvAvgCalorie.setText("평균 칼로리소모량 : "+avgCalorie+"kcal");

        recentCalorie = Float.toString((float) ((Math.round(calorie1/0.01)) *0.01));
        tvRecentCalorie.setText("최근 칼로리소모량 : "+recentCalorie+"kcal");

        btnMain.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(),MainActivity.class);
                startActivity(intent);
            }
        });

        btnMap.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent Map = new Intent(getApplicationContext(),Map.class);
                startActivity(Map);
            }
        });

        //막대 차트
        stepChart.addBar(new BarModel("5",stepCount5,0xFF1FF4AC));
        stepChart.addBar(new BarModel("4",stepCount4,0xFF1FF4AC));
        stepChart.addBar(new BarModel("3",stepCount3,0xFF1FF4AC));
        stepChart.addBar(new BarModel("2",stepCount2,0xFF1FF4AC));
        stepChart.addBar(new BarModel("1",stepCount1,0xFF1FF4AC));

        //막대 차트-1
        calorieChart.addBar(new BarModel("5",calorie5,0xFFBE32BE));
        calorieChart.addBar(new BarModel("4",calorie4,0xFFBE32BE));
        calorieChart.addBar(new BarModel("3",calorie3,0xFFBE32BE));
        calorieChart.addBar(new BarModel("2",calorie2,0xFFBE32BE));
        calorieChart.addBar(new BarModel("1",calorie1,0xFFBE32BE));


    }
}
