package com.bliss.csc.stepcalories;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;

public class Login extends AppCompatActivity {

    Button btnActivity, btnMain, btnMap;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.login);

        btnActivity = (Button)findViewById(R.id.btnActivity);
        btnMain = (Button)findViewById(R.id.btnMain);
        btnMap = (Button)findViewById(R.id.btnMap);

        btnActivity.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent Activity = new Intent(getApplicationContext(),Activation.class);
                startActivity(Activity);
            }
        });

        btnMain.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });

        btnMap.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent Map = new Intent(getApplicationContext(),Map.class);
                startActivity(Map);
            }
        });

    }

}
