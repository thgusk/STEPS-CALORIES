package com.cookandroid.main_project;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class Main_project_Activation extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_project__activation);
    }
}