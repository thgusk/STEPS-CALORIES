package com.bliss.csc.stepcalories;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class Activation extends AppCompatActivity {

    Button btnMain, btnMap;
    TextView tvStepCount2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activation);

        btnMain = (Button)findViewById(R.id.btnMain);
        btnMap = (Button)findViewById(R.id.btnMap);

        btnMain.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });

        btnMap.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent Map = new Intent(getApplicationContext(),Map.class);
                startActivity(Map);
            }
        });

        //tvStepCount2.setText("실제 : "+MainActivity.stepCount+" 보");
    }

}
